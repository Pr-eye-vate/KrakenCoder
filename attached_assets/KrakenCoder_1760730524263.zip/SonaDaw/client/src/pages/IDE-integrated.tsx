import { useState, useEffect, useCallback, useRef } from 'react';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { FileTree } from '@/components/ide/FileTree';
import { EditorTabs } from '@/components/ide/EditorTabs';
import { CodeEditor } from '@/components/ide/CodeEditor';
import { Terminal } from '@/components/ide/Terminal';
import { AIChat } from '@/components/ide/AIChat';
import { StatusBar } from '@/components/ide/StatusBar';
import { TopBar } from '@/components/ide/TopBar';
import { CommandPalette } from '@/components/ide/CommandPalette';
import { SettingsPanel } from '@/components/ide/SettingsPanel';
import { FileNode, EditorTab, TerminalSession, ChatMessage, Settings } from '@shared/schema';
import { 
  useFileTree, 
  useWriteFile, 
  useCreateFile, 
  useDeleteFile, 
  useRenameFile,
  useSendChatMessage,
  useSettings,
  useSaveSettings,
  useExecuteCommand,
} from '@/hooks/useIDE';
import { useToast } from '@/hooks/use-toast';

const DEFAULT_SETTINGS: Settings = {
  theme: 'dark',
  fontSize: 14,
  fontFamily: 'JetBrains Mono',
  aiModel: 'gpt-5',
  autoSave: true,
  formatOnSave: false,
  minimap: true,
  lineNumbers: true,
  wordWrap: true,
  tabSize: 2,
};

export default function IDE() {
  const [tabs, setTabs] = useState<EditorTab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | undefined>();
  const [terminalSessions, setTerminalSessions] = useState<TerminalSession[]>([
    { id: '1', name: 'Terminal 1', cwd: '~' },
  ]);
  const [activeTerminalId, setActiveTerminalId] = useState('1');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [settingsPanelOpen, setSettingsPanelOpen] = useState(false);
  const [cursorPosition, setCursorPosition] = useState({ lineNumber: 1, column: 1 });
  const [aiStatus, setAiStatus] = useState<'idle' | 'thinking' | 'ready'>('ready');
  const autoSaveTimerRef = useRef<NodeJS.Timeout>();
  const { toast } = useToast();

  // API Hooks
  const { data: fileTree = [], isLoading: filesLoading } = useFileTree();
  const { data: settingsData } = useSettings();
  const writeFile = useWriteFile();
  const createFile = useCreateFile();
  const deleteFile = useDeleteFile();
  const renameFile = useRenameFile();
  // Track streaming message ID
  const streamingMessageRef = useRef<string | null>(null);
  
  const sendChatMessage = useSendChatMessage((content) => {
    // Update the streaming message progressively
    if (streamingMessageRef.current) {
      setChatMessages((prev) =>
        prev.map((msg) =>
          msg.id === streamingMessageRef.current
            ? { ...msg, content }
            : msg
        )
      );
    }
  });
  const saveSettings = useSaveSettings();
  const executeCommand = useExecuteCommand();

  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);

  // Sync settings from server
  useEffect(() => {
    if (settingsData) {
      setSettings(settingsData);
    }
  }, [settingsData]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(true);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'p') {
        e.preventDefault();
        setCommandPaletteOpen(true);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault();
        handleSaveFile();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTabId, tabs]);

  // Apply theme
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.theme]);

  // Auto-save
  useEffect(() => {
    if (!settings.autoSave || !activeTabId) return;

    const tab = tabs.find((t) => t.id === activeTabId);
    if (!tab || !tab.isDirty) return;

    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current);
    }

    autoSaveTimerRef.current = setTimeout(() => {
      handleSaveFile();
    }, 2000);

    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current);
      }
    };
  }, [tabs, activeTabId, settings.autoSave]);

  const handleFileSelect = useCallback((node: FileNode) => {
    if (node.type === 'folder') return;

    const existingTab = tabs.find((tab) => tab.path === node.path);
    if (existingTab) {
      setActiveTabId(existingTab.id);
      return;
    }

    const newTab: EditorTab = {
      id: node.id,
      path: node.path,
      name: node.name,
      content: node.content || '',
      language: node.language || 'plaintext',
      isDirty: false,
    };

    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newTab.id);
  }, [tabs]);

  const handleTabClose = useCallback((tabId: string) => {
    setTabs((prev) => {
      const filtered = prev.filter((tab) => tab.id !== tabId);
      if (activeTabId === tabId && filtered.length > 0) {
        setActiveTabId(filtered[filtered.length - 1].id);
      } else if (filtered.length === 0) {
        setActiveTabId(undefined);
      }
      return filtered;
    });
  }, [activeTabId]);

  const handleEditorChange = useCallback((value: string | undefined) => {
    if (!activeTabId || !value) return;

    setTabs((prev) =>
      prev.map((tab) =>
        tab.id === activeTabId
          ? { ...tab, content: value, isDirty: true }
          : tab
      )
    );
  }, [activeTabId]);

  const handleSaveFile = useCallback(async () => {
    if (!activeTabId) return;

    const tab = tabs.find((t) => t.id === activeTabId);
    if (!tab) return;

    await writeFile.mutateAsync({ path: tab.path, content: tab.content });

    setTabs((prev) =>
      prev.map((t) => (t.id === activeTabId ? { ...t, isDirty: false } : t))
    );
  }, [activeTabId, tabs, writeFile]);

  const handleFileCreate = useCallback(async (parentPath: string, type: 'file' | 'folder') => {
    const name = prompt(`Enter ${type} name:`);
    if (!name) return;

    const newPath = `${parentPath}/${name}`;
    await createFile.mutateAsync({ path: newPath, type });
  }, [createFile]);

  const handleFileDelete = useCallback(async (path: string) => {
    if (!confirm(`Are you sure you want to delete ${path}?`)) return;
    await deleteFile.mutateAsync(path);
  }, [deleteFile]);

  const handleFileRename = useCallback(async (path: string) => {
    const fileName = path.split('/').pop() || '';
    const newName = prompt('Enter new name:', fileName);
    if (!newName || newName === fileName) return;

    const newPath = path.substring(0, path.lastIndexOf('/')) + '/' + newName;
    await renameFile.mutateAsync({ path, newPath });
  }, [renameFile]);

  const handleTerminalCommand = useCallback(async (sessionId: string, command: string) => {
    try {
      const result = await executeCommand.mutateAsync({ sessionId, command });
      console.log('Command result:', result);
    } catch (error) {
      console.error('Command error:', error);
    }
  }, [executeCommand]);

  const handleSendMessage = useCallback(async (message: string) => {
    const activeTab = tabs.find((t) => t.id === activeTabId);
    
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: Date.now(),
    };

    setChatMessages((prev) => [...prev, userMessage]);
    setAiStatus('thinking');

    // Create a placeholder message for streaming
    const streamingId = Date.now().toString();
    streamingMessageRef.current = streamingId;
    
    const placeholderMessage: ChatMessage = {
      id: streamingId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
    };
    
    setChatMessages((prev) => [...prev, placeholderMessage]);

    try {
      // Build conversation history from existing messages
      const history = chatMessages
        .filter(msg => msg.role !== 'system')
        .map(msg => ({
          role: msg.role as 'user' | 'assistant',
          content: msg.content,
        }));
      
      await sendChatMessage.mutateAsync({
        message,
        context: activeTab ? {
          currentFile: activeTab.path,
          language: activeTab.language,
        } : undefined,
        conversationHistory: history,
      });
    } catch (error) {
      // Remove the placeholder message on error
      setChatMessages((prev) => prev.filter((msg) => msg.id !== streamingId));
      
      toast({
        title: 'AI Chat Error',
        description: 'Failed to get response from AI. Please try again.',
        variant: 'destructive',
      });
    } finally {
      streamingMessageRef.current = null;
      setAiStatus('ready');
    }
  }, [activeTabId, tabs, sendChatMessage, toast]);

  const handleSettingsChange = useCallback(async (newSettings: Partial<Settings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    await saveSettings.mutateAsync(updated);
  }, [settings, saveSettings]);

  const activeTab = tabs.find((tab) => tab.id === activeTabId);

  if (filesLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading CodeForge IDE...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-background text-foreground" data-testid="ide">
      <TopBar
        onSettingsClick={() => setSettingsPanelOpen(true)}
        onCommandPaletteClick={() => setCommandPaletteOpen(true)}
        theme={settings.theme}
        onThemeToggle={() =>
          handleSettingsChange({ theme: settings.theme === 'dark' ? 'light' : 'dark' })
        }
      />

      <div className="flex-1 overflow-hidden">
        <PanelGroup direction="horizontal">
          <Panel defaultSize={20} minSize={15} maxSize={30}>
            <div className="h-full bg-sidebar border-r border-sidebar-border">
              <div className="p-3 border-b border-sidebar-border">
                <h2 className="font-semibold text-sm">Explorer</h2>
              </div>
              <FileTree
                nodes={fileTree}
                selectedPath={activeTab?.path}
                onFileSelect={handleFileSelect}
                onFileCreate={handleFileCreate}
                onFileDelete={handleFileDelete}
                onFileRename={handleFileRename}
              />
            </div>
          </Panel>

          <PanelResizeHandle className="w-1 bg-border hover:bg-primary/50 transition-colors" />

          <Panel defaultSize={55} minSize={30}>
            <PanelGroup direction="vertical">
              <Panel defaultSize={70} minSize={30}>
                <div className="h-full flex flex-col bg-background">
                  <EditorTabs
                    tabs={tabs}
                    activeTabId={activeTabId}
                    onTabClick={setActiveTabId}
                    onTabClose={handleTabClose}
                  />
                  {activeTab ? (
                    <div className="flex-1 overflow-hidden">
                      <CodeEditor
                        value={activeTab.content}
                        language={activeTab.language}
                        onChange={handleEditorChange}
                        onCursorChange={setCursorPosition}
                      />
                    </div>
                  ) : (
                    <div className="flex-1 flex items-center justify-center text-muted-foreground">
                      <div className="text-center">
                        <p className="text-lg mb-2">No file open</p>
                        <p className="text-sm">Select a file from the explorer to start editing</p>
                      </div>
                    </div>
                  )}
                </div>
              </Panel>

              <PanelResizeHandle className="h-1 bg-border hover:bg-primary/50 transition-colors" />

              <Panel defaultSize={30} minSize={15} maxSize={50}>
                <Terminal
                  sessions={terminalSessions}
                  activeSessionId={activeTerminalId}
                  onSessionChange={setActiveTerminalId}
                  onSessionCreate={() => {
                    const newSession: TerminalSession = {
                      id: Date.now().toString(),
                      name: `Terminal ${terminalSessions.length + 1}`,
                      cwd: '~',
                    };
                    setTerminalSessions((prev) => [...prev, newSession]);
                    setActiveTerminalId(newSession.id);
                  }}
                  onSessionClose={(id) => {
                    setTerminalSessions((prev) => {
                      const filtered = prev.filter((s) => s.id !== id);
                      if (activeTerminalId === id && filtered.length > 0) {
                        setActiveTerminalId(filtered[0].id);
                      }
                      return filtered;
                    });
                  }}
                  onCommand={handleTerminalCommand}
                />
              </Panel>
            </PanelGroup>
          </Panel>

          <PanelResizeHandle className="w-1 bg-border hover:bg-primary/50 transition-colors" />

          <Panel defaultSize={25} minSize={20} maxSize={40}>
            <AIChat
              messages={chatMessages}
              onSendMessage={handleSendMessage}
              isLoading={aiStatus === 'thinking'}
            />
          </Panel>
        </PanelGroup>
      </div>

      <StatusBar
        cursorPosition={cursorPosition}
        language={activeTab?.language}
        fileEncoding="UTF-8"
        aiStatus={aiStatus}
        errors={0}
        warnings={0}
      />

      <CommandPalette
        open={commandPaletteOpen}
        onOpenChange={setCommandPaletteOpen}
      />

      <SettingsPanel
        open={settingsPanelOpen}
        onOpenChange={setSettingsPanelOpen}
        settings={settings}
        onSettingsChange={handleSettingsChange}
      />
    </div>
  );
}

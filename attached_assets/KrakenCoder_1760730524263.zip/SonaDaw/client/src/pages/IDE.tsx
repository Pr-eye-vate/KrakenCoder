import { useState, useEffect, useCallback } from 'react';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { FileTree } from '@/components/ide/FileTree';
import { EditorTabs } from '@/components/ide/EditorTabs';
import { CodeEditor } from '@/components/ide/CodeEditor';
import { Terminal } from '@/components/ide/Terminal';
import { AIChat } from '@/components/ide/AIChat';
import { StatusBar } from '@/components/ide/StatusBar';
import { TopBar } from '@/components/ide/TopBar';
import { CommandPalette } from '@/components/ide/CommandPalette';
import { SettingsPanel } from '@/components/ide/SettingsPanel';
import { FileNode, EditorTab, TerminalSession, ChatMessage, Settings } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

const DEFAULT_SETTINGS: Settings = {
  theme: 'dark',
  fontSize: 14,
  fontFamily: 'JetBrains Mono',
  aiModel: 'gpt-5',
  autoSave: true,
  formatOnSave: false,
  minimap: true,
  lineNumbers: true,
  wordWrap: true,
  tabSize: 2,
};

// Sample initial file tree
const INITIAL_FILES: FileNode[] = [
  {
    id: '1',
    name: 'src',
    type: 'folder',
    path: '/src',
    isOpen: true,
    children: [
      {
        id: '2',
        name: 'App.tsx',
        type: 'file',
        path: '/src/App.tsx',
        language: 'typescript',
        content: `import { useState } from 'react';\n\nfunction App() {\n  const [count, setCount] = useState(0);\n\n  return (\n    <div className="App">\n      <h1>Welcome to CodeForge IDE</h1>\n      <p>Count: {count}</p>\n      <button onClick={() => setCount(count + 1)}>\n        Increment\n      </button>\n    </div>\n  );\n}\n\nexport default App;\n`,
      },
      {
        id: '3',
        name: 'index.tsx',
        type: 'file',
        path: '/src/index.tsx',
        language: 'typescript',
        content: `import React from 'react';\nimport ReactDOM from 'react-dom/client';\nimport App from './App';\nimport './index.css';\n\nReactDOM.createRoot(document.getElementById('root')!).render(\n  <React.StrictMode>\n    <App />\n  </React.StrictMode>\n);\n`,
      },
    ],
  },
  {
    id: '4',
    name: 'package.json',
    type: 'file',
    path: '/package.json',
    language: 'json',
    content: `{\n  "name": "my-project",\n  "version": "1.0.0",\n  "type": "module",\n  "scripts": {\n    "dev": "vite",\n    "build": "vite build"\n  },\n  "dependencies": {\n    "react": "^18.2.0",\n    "react-dom": "^18.2.0"\n  }\n}\n`,
  },
  {
    id: '5',
    name: 'README.md',
    type: 'file',
    path: '/README.md',
    language: 'markdown',
    content: `# My Project\n\nWelcome to your new project!\n\n## Getting Started\n\n1. Install dependencies: \`npm install\`\n2. Start the dev server: \`npm run dev\`\n3. Open your browser and start coding!\n\n## Features\n\n- Fast development with Vite\n- React 18\n- TypeScript support\n`,
  },
];

export default function IDE() {
  const [files, setFiles] = useState<FileNode[]>(INITIAL_FILES);
  const [tabs, setTabs] = useState<EditorTab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | undefined>();
  const [terminalSessions, setTerminalSessions] = useState<TerminalSession[]>([
    { id: '1', name: 'Terminal 1', cwd: '~' },
  ]);
  const [activeTerminalId, setActiveTerminalId] = useState('1');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [settingsPanelOpen, setSettingsPanelOpen] = useState(false);
  const [cursorPosition, setCursorPosition] = useState({ lineNumber: 1, column: 1 });
  const [aiStatus, setAiStatus] = useState<'idle' | 'thinking' | 'ready'>('ready');
  const { toast } = useToast();

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(true);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'p') {
        e.preventDefault();
        setCommandPaletteOpen(true);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault();
        handleSaveFile();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTabId, tabs]);

  // Apply theme
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.theme]);

  const findFileByPath = (nodes: FileNode[], path: string): FileNode | null => {
    for (const node of nodes) {
      if (node.path === path) return node;
      if (node.children) {
        const found = findFileByPath(node.children, path);
        if (found) return found;
      }
    }
    return null;
  };

  const handleFileSelect = useCallback((node: FileNode) => {
    if (node.type === 'folder') return;

    const existingTab = tabs.find((tab) => tab.path === node.path);
    if (existingTab) {
      setActiveTabId(existingTab.id);
      return;
    }

    const newTab: EditorTab = {
      id: node.id,
      path: node.path,
      name: node.name,
      content: node.content || '',
      language: node.language || 'plaintext',
      isDirty: false,
    };

    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newTab.id);
  }, [tabs]);

  const handleTabClose = useCallback((tabId: string) => {
    setTabs((prev) => {
      const filtered = prev.filter((tab) => tab.id !== tabId);
      if (activeTabId === tabId && filtered.length > 0) {
        setActiveTabId(filtered[filtered.length - 1].id);
      } else if (filtered.length === 0) {
        setActiveTabId(undefined);
      }
      return filtered;
    });
  }, [activeTabId]);

  const handleEditorChange = useCallback((value: string | undefined) => {
    if (!activeTabId || !value) return;

    setTabs((prev) =>
      prev.map((tab) =>
        tab.id === activeTabId
          ? { ...tab, content: value, isDirty: true }
          : tab
      )
    );
  }, [activeTabId]);

  const handleSaveFile = useCallback(() => {
    if (!activeTabId) return;

    const tab = tabs.find((t) => t.id === activeTabId);
    if (!tab) return;

    setTabs((prev) =>
      prev.map((t) => (t.id === activeTabId ? { ...t, isDirty: false } : t))
    );

    toast({
      title: 'File saved',
      description: `${tab.name} has been saved successfully.`,
    });
  }, [activeTabId, tabs, toast]);

  const handleFileCreate = useCallback((parentPath: string, type: 'file' | 'folder') => {
    const name = prompt(`Enter ${type} name:`);
    if (!name) return;

    const newPath = `${parentPath}/${name}`;
    const newNode: FileNode = {
      id: Date.now().toString(),
      name,
      type,
      path: newPath,
      content: type === 'file' ? '' : undefined,
      language: type === 'file' ? 'plaintext' : undefined,
      children: type === 'folder' ? [] : undefined,
    };

    // This is a simplified version - in production, you'd update the server
    toast({
      title: `${type === 'file' ? 'File' : 'Folder'} created`,
      description: newPath,
    });
  }, [toast]);

  const handleFileDelete = useCallback((path: string) => {
    if (!confirm(`Are you sure you want to delete ${path}?`)) return;

    toast({
      title: 'File deleted',
      description: path,
    });
  }, [toast]);

  const handleFileRename = useCallback((path: string) => {
    const newName = prompt('Enter new name:');
    if (!newName) return;

    toast({
      title: 'File renamed',
      description: `${path} → ${newName}`,
    });
  }, [toast]);

  const handleTerminalCommand = useCallback((sessionId: string, command: string) => {
    console.log(`Terminal ${sessionId}: ${command}`);
    toast({
      title: 'Command executed',
      description: command,
    });
  }, [toast]);

  const handleSendMessage = useCallback(async (message: string) => {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: Date.now(),
    };

    setChatMessages((prev) => [...prev, userMessage]);
    setAiStatus('thinking');

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `I understand you're asking about: "${message}"\n\nHere's a code example:\n\n\`\`\`typescript\nfunction example() {\n  console.log("Hello from CodeForge!");\n}\n\`\`\`\n\nThis is a placeholder response. In production, this would connect to the OpenAI API for real assistance.`,
        timestamp: Date.now(),
      };

      setChatMessages((prev) => [...prev, aiMessage]);
      setAiStatus('ready');
    }, 1500);
  }, []);

  const activeTab = tabs.find((tab) => tab.id === activeTabId);

  return (
    <div className="h-screen flex flex-col bg-background text-foreground" data-testid="ide">
      <TopBar
        onSettingsClick={() => setSettingsPanelOpen(true)}
        onCommandPaletteClick={() => setCommandPaletteOpen(true)}
        theme={settings.theme}
        onThemeToggle={() =>
          setSettings((prev) => ({ ...prev, theme: prev.theme === 'dark' ? 'light' : 'dark' }))
        }
      />

      <div className="flex-1 overflow-hidden">
        <PanelGroup direction="horizontal">
          {/* File Tree Sidebar */}
          <Panel defaultSize={20} minSize={15} maxSize={30}>
            <div className="h-full bg-sidebar border-r border-sidebar-border">
              <div className="p-3 border-b border-sidebar-border">
                <h2 className="font-semibold text-sm">Explorer</h2>
              </div>
              <FileTree
                nodes={files}
                selectedPath={activeTab?.path}
                onFileSelect={handleFileSelect}
                onFileCreate={handleFileCreate}
                onFileDelete={handleFileDelete}
                onFileRename={handleFileRename}
              />
            </div>
          </Panel>

          <PanelResizeHandle className="w-1 bg-border hover:bg-primary/50 transition-colors" />

          {/* Main Editor Area */}
          <Panel defaultSize={55} minSize={30}>
            <PanelGroup direction="vertical">
              <Panel defaultSize={70} minSize={30}>
                <div className="h-full flex flex-col bg-background">
                  <EditorTabs
                    tabs={tabs}
                    activeTabId={activeTabId}
                    onTabClick={setActiveTabId}
                    onTabClose={handleTabClose}
                  />
                  {activeTab ? (
                    <div className="flex-1 overflow-hidden">
                      <CodeEditor
                        value={activeTab.content}
                        language={activeTab.language}
                        onChange={handleEditorChange}
                        onCursorChange={setCursorPosition}
                      />
                    </div>
                  ) : (
                    <div className="flex-1 flex items-center justify-center text-muted-foreground">
                      <div className="text-center">
                        <p className="text-lg mb-2">No file open</p>
                        <p className="text-sm">Select a file from the explorer to start editing</p>
                      </div>
                    </div>
                  )}
                </div>
              </Panel>

              <PanelResizeHandle className="h-1 bg-border hover:bg-primary/50 transition-colors" />

              {/* Terminal */}
              <Panel defaultSize={30} minSize={15} maxSize={50}>
                <Terminal
                  sessions={terminalSessions}
                  activeSessionId={activeTerminalId}
                  onSessionChange={setActiveTerminalId}
                  onSessionCreate={() => {
                    const newSession: TerminalSession = {
                      id: Date.now().toString(),
                      name: `Terminal ${terminalSessions.length + 1}`,
                      cwd: '~',
                    };
                    setTerminalSessions((prev) => [...prev, newSession]);
                    setActiveTerminalId(newSession.id);
                  }}
                  onSessionClose={(id) => {
                    setTerminalSessions((prev) => {
                      const filtered = prev.filter((s) => s.id !== id);
                      if (activeTerminalId === id && filtered.length > 0) {
                        setActiveTerminalId(filtered[0].id);
                      }
                      return filtered;
                    });
                  }}
                  onCommand={handleTerminalCommand}
                />
              </Panel>
            </PanelGroup>
          </Panel>

          <PanelResizeHandle className="w-1 bg-border hover:bg-primary/50 transition-colors" />

          {/* AI Chat Panel */}
          <Panel defaultSize={25} minSize={20} maxSize={40}>
            <AIChat
              messages={chatMessages}
              onSendMessage={handleSendMessage}
              isLoading={aiStatus === 'thinking'}
            />
          </Panel>
        </PanelGroup>
      </div>

      <StatusBar
        cursorPosition={cursorPosition}
        language={activeTab?.language}
        fileEncoding="UTF-8"
        aiStatus={aiStatus}
        errors={0}
        warnings={0}
      />

      <CommandPalette
        open={commandPaletteOpen}
        onOpenChange={setCommandPaletteOpen}
      />

      <SettingsPanel
        open={settingsPanelOpen}
        onOpenChange={setSettingsPanelOpen}
        settings={settings}
        onSettingsChange={(newSettings) =>
          setSettings((prev) => ({ ...prev, ...newSettings }))
        }
      />
    </div>
  );
}

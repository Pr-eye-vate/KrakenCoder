import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { FileNode, ChatMessage, Settings, ChatRequest } from '@shared/schema';
import { useToast } from './use-toast';

// File Operations
export function useFileTree() {
  return useQuery<FileNode[]>({
    queryKey: ['/api/files'],
    retry: 1,
  });
}

export function useReadFile(path: string | undefined) {
  return useQuery<{ content: string }>({
    queryKey: ['/api/files/read', path],
    enabled: !!path,
    retry: 1,
  });
}

export function useWriteFile() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ path, content }: { path: string; content: string }) => {
      return apiRequest('POST', '/api/files/write', {
        operation: 'write',
        path,
        content,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: 'File saved',
        description: 'Your changes have been saved successfully.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Save failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
}

export function useCreateFile() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ path, type }: { path: string; type: 'file' | 'folder' }) => {
      return apiRequest('POST', '/api/files/create', {
        operation: 'create',
        path,
        type,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: 'Created successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Creation failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
}

export function useDeleteFile() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (path: string) => {
      return apiRequest('POST', '/api/files/delete', {
        operation: 'delete',
        path,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: 'Deleted successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Deletion failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
}

export function useRenameFile() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ path, newPath }: { path: string; newPath: string }) => {
      return apiRequest('POST', '/api/files/rename', {
        operation: 'rename',
        path,
        newPath,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: 'Renamed successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Rename failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
}

export function useSearchFiles() {
  return useMutation({
    mutationFn: async (query: string) => {
      return apiRequest('POST', '/api/files/search', {
        query,
        caseSensitive: false,
        regex: false,
      });
    },
  });
}

// AI Operations with progressive streaming support
export function useSendChatMessage(onChunk?: (content: string) => void) {
  return useMutation({
    mutationFn: async (request: ChatRequest): Promise<ChatMessage> => {
      // Use fetch for streaming SSE support
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      // Read the SSE stream progressively
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let messageData: any = null;

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              if (data === '[DONE]') break;
              
              try {
                const parsed = JSON.parse(data);
                messageData = parsed;
                
                // Call the chunk callback for progressive rendering
                if (onChunk && parsed.content) {
                  onChunk(parsed.content);
                }
              } catch (e) {
                // Ignore parse errors
              }
            }
          }
        }
      }

      return messageData || {
        id: Date.now().toString(),
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
      };
    },
  });
}

export function useCodeCompletion() {
  return useMutation({
    mutationFn: async (request: {
      code: string;
      language: string;
      position: { lineNumber: number; column: number };
      context?: string;
    }) => {
      return apiRequest('POST', '/api/ai/complete', request);
    },
  });
}

export function useFormatCode() {
  return useMutation({
    mutationFn: async ({ code, language }: { code: string; language: string }) => {
      return apiRequest('POST', '/api/ai/format', { code, language });
    },
  });
}

// Settings
export function useSettings() {
  return useQuery<Settings>({
    queryKey: ['/api/settings'],
    retry: 1,
  });
}

export function useSaveSettings() {
  return useMutation({
    mutationFn: async (settings: Settings) => {
      return apiRequest('POST', '/api/settings', settings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
    },
  });
}

// Terminal
export function useExecuteCommand() {
  return useMutation({
    mutationFn: async ({ sessionId, command }: { sessionId: string; command: string }) => {
      return apiRequest('POST', '/api/terminal/execute', {
        sessionId,
        command,
      });
    },
  });
}

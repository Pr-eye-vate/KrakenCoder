import { Code2, Settings, Moon, Sun, Command } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface TopBarProps {
  onSettingsClick: () => void;
  onCommandPaletteClick: () => void;
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
}

export function TopBar({ onSettingsClick, onCommandPaletteClick, theme, onThemeToggle }: TopBarProps) {
  return (
    <div className="h-12 bg-sidebar border-b border-sidebar-border flex items-center justify-between px-4" data-testid="top-bar">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Code2 className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="font-semibold text-lg">CodeForge</span>
        </div>

        <div className="h-6 w-px bg-border" />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8" data-testid="menu-file">
              File
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem data-testid="file-new">New File</DropdownMenuItem>
            <DropdownMenuItem data-testid="file-open">Open File</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="file-save">Save</DropdownMenuItem>
            <DropdownMenuItem data-testid="file-save-all">Save All</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="file-close">Close Editor</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8" data-testid="menu-edit">
              Edit
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem data-testid="edit-undo">Undo</DropdownMenuItem>
            <DropdownMenuItem data-testid="edit-redo">Redo</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="edit-cut">Cut</DropdownMenuItem>
            <DropdownMenuItem data-testid="edit-copy">Copy</DropdownMenuItem>
            <DropdownMenuItem data-testid="edit-paste">Paste</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="edit-find">Find</DropdownMenuItem>
            <DropdownMenuItem data-testid="edit-replace">Replace</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8" data-testid="menu-view">
              View
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem data-testid="view-command-palette" onClick={onCommandPaletteClick}>
              Command Palette
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="view-explorer">Explorer</DropdownMenuItem>
            <DropdownMenuItem data-testid="view-search">Search</DropdownMenuItem>
            <DropdownMenuItem data-testid="view-terminal">Terminal</DropdownMenuItem>
            <DropdownMenuItem data-testid="view-ai-chat">AI Chat</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={onCommandPaletteClick}
          data-testid="button-command-palette"
        >
          <Command className="w-4 h-4" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={onThemeToggle}
          data-testid="button-theme-toggle"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={onSettingsClick}
          data-testid="button-settings"
        >
          <Settings className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

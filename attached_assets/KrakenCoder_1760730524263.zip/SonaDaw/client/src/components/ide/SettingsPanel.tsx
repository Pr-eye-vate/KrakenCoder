import { Settings as SettingsType } from '@shared/schema';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';

interface SettingsPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  settings: SettingsType;
  onSettingsChange: (settings: Partial<SettingsType>) => void;
}

export function SettingsPanel({ open, onOpenChange, settings, onSettingsChange }: SettingsPanelProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col" data-testid="settings-panel">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="editor" className="flex-1 overflow-hidden">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="editor" data-testid="settings-tab-editor">Editor</TabsTrigger>
            <TabsTrigger value="ai" data-testid="settings-tab-ai">AI</TabsTrigger>
            <TabsTrigger value="appearance" data-testid="settings-tab-appearance">Appearance</TabsTrigger>
          </TabsList>

          <div className="overflow-y-auto max-h-[calc(80vh-180px)] mt-4">
            <TabsContent value="editor" className="space-y-6 mt-0">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="auto-save">Auto Save</Label>
                    <p className="text-sm text-muted-foreground">Automatically save files when editing</p>
                  </div>
                  <Switch
                    id="auto-save"
                    checked={settings.autoSave}
                    onCheckedChange={(checked) => onSettingsChange({ autoSave: checked })}
                    data-testid="setting-auto-save"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="format-on-save">Format on Save</Label>
                    <p className="text-sm text-muted-foreground">Format code automatically when saving</p>
                  </div>
                  <Switch
                    id="format-on-save"
                    checked={settings.formatOnSave}
                    onCheckedChange={(checked) => onSettingsChange({ formatOnSave: checked })}
                    data-testid="setting-format-on-save"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="minimap">Show Minimap</Label>
                    <p className="text-sm text-muted-foreground">Display code minimap on the right</p>
                  </div>
                  <Switch
                    id="minimap"
                    checked={settings.minimap}
                    onCheckedChange={(checked) => onSettingsChange({ minimap: checked })}
                    data-testid="setting-minimap"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="line-numbers">Line Numbers</Label>
                    <p className="text-sm text-muted-foreground">Show line numbers in editor</p>
                  </div>
                  <Switch
                    id="line-numbers"
                    checked={settings.lineNumbers}
                    onCheckedChange={(checked) => onSettingsChange({ lineNumbers: checked })}
                    data-testid="setting-line-numbers"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="word-wrap">Word Wrap</Label>
                    <p className="text-sm text-muted-foreground">Wrap long lines</p>
                  </div>
                  <Switch
                    id="word-wrap"
                    checked={settings.wordWrap}
                    onCheckedChange={(checked) => onSettingsChange({ wordWrap: checked })}
                    data-testid="setting-word-wrap"
                  />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="tab-size">Tab Size: {settings.tabSize}</Label>
                  <Slider
                    id="tab-size"
                    min={2}
                    max={8}
                    step={2}
                    value={[settings.tabSize]}
                    onValueChange={([value]) => onSettingsChange({ tabSize: value })}
                    data-testid="setting-tab-size"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="ai" className="space-y-6 mt-0">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="ai-model">AI Model</Label>
                  <Select
                    value={settings.aiModel}
                    onValueChange={(value: 'gpt-5' | 'gpt-4o') => onSettingsChange({ aiModel: value })}
                  >
                    <SelectTrigger id="ai-model" data-testid="setting-ai-model">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gpt-5">GPT-5 (Latest)</SelectItem>
                      <SelectItem value="gpt-4o">GPT-4o</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground">
                    Choose which AI model to use for code assistance
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="appearance" className="space-y-6 mt-0">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="theme">Theme</Label>
                  <Select
                    value={settings.theme}
                    onValueChange={(value: 'light' | 'dark') => onSettingsChange({ theme: value })}
                  >
                    <SelectTrigger id="theme" data-testid="setting-theme">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="light">Light</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="font-size">Font Size: {settings.fontSize}px</Label>
                  <Slider
                    id="font-size"
                    min={10}
                    max={24}
                    step={1}
                    value={[settings.fontSize]}
                    onValueChange={([value]) => onSettingsChange({ fontSize: value })}
                    data-testid="setting-font-size"
                  />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="font-family">Font Family</Label>
                  <Select
                    value={settings.fontFamily}
                    onValueChange={(value) => onSettingsChange({ fontFamily: value })}
                  >
                    <SelectTrigger id="font-family" data-testid="setting-font-family">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="JetBrains Mono">JetBrains Mono</SelectItem>
                      <SelectItem value="Fira Code">Fira Code</SelectItem>
                      <SelectItem value="Consolas">Consolas</SelectItem>
                      <SelectItem value="Monaco">Monaco</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

import { useState, useEffect, useRef } from 'react';
import { Search, FileText, Terminal as TerminalIcon, MessageSquare, Settings, Zap } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface Command {
  id: string;
  label: string;
  description?: string;
  icon: React.ReactNode;
  action: () => void;
  keywords?: string[];
}

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  commands?: Command[];
}

const defaultCommands: Command[] = [
  {
    id: 'new-file',
    label: 'New File',
    description: 'Create a new file',
    icon: <FileText className="w-4 h-4" />,
    action: () => console.log('New file'),
    keywords: ['create', 'file', 'new'],
  },
  {
    id: 'open-terminal',
    label: 'Toggle Terminal',
    description: 'Show or hide the integrated terminal',
    icon: <TerminalIcon className="w-4 h-4" />,
    action: () => console.log('Toggle terminal'),
    keywords: ['terminal', 'console', 'shell'],
  },
  {
    id: 'open-ai-chat',
    label: 'Open AI Chat',
    description: 'Open the AI assistant panel',
    icon: <MessageSquare className="w-4 h-4" />,
    action: () => console.log('Open AI chat'),
    keywords: ['ai', 'assistant', 'chat', 'help'],
  },
  {
    id: 'settings',
    label: 'Open Settings',
    description: 'Configure editor preferences',
    icon: <Settings className="w-4 h-4" />,
    action: () => console.log('Settings'),
    keywords: ['settings', 'preferences', 'config'],
  },
  {
    id: 'format',
    label: 'Format Document',
    description: 'Format the current file',
    icon: <Zap className="w-4 h-4" />,
    action: () => console.log('Format'),
    keywords: ['format', 'prettier', 'beautify'],
  },
];

export function CommandPalette({ open, onOpenChange, commands = defaultCommands }: CommandPaletteProps) {
  const [search, setSearch] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredCommands = commands.filter((cmd) => {
    const searchLower = search.toLowerCase();
    return (
      cmd.label.toLowerCase().includes(searchLower) ||
      cmd.description?.toLowerCase().includes(searchLower) ||
      cmd.keywords?.some((kw) => kw.toLowerCase().includes(searchLower))
    );
  });

  useEffect(() => {
    if (open) {
      setSearch('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 0);
    }
  }, [open]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [search]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((i) => (i + 1) % filteredCommands.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((i) => (i - 1 + filteredCommands.length) % filteredCommands.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredCommands[selectedIndex]) {
        filteredCommands[selectedIndex].action();
        onOpenChange(false);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0 gap-0" data-testid="command-palette">
        <div className="p-4 border-b border-border">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              ref={inputRef}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a command or search..."
              className="pl-10"
              data-testid="command-palette-input"
            />
          </div>
        </div>

        <ScrollArea className="max-h-[400px]">
          <div className="p-2">
            {filteredCommands.length === 0 ? (
              <div className="py-12 text-center text-muted-foreground">
                <p>No commands found</p>
              </div>
            ) : (
              filteredCommands.map((cmd, index) => (
                <button
                  key={cmd.id}
                  className={cn(
                    'w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors hover-elevate',
                    selectedIndex === index && 'bg-accent'
                  )}
                  onClick={() => {
                    cmd.action();
                    onOpenChange(false);
                  }}
                  onMouseEnter={() => setSelectedIndex(index)}
                  data-testid={`command-${cmd.id}`}
                >
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                    {cmd.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm">{cmd.label}</div>
                    {cmd.description && (
                      <div className="text-xs text-muted-foreground truncate">{cmd.description}</div>
                    )}
                  </div>
                </button>
              ))
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from 'react';
import { ChevronRight, ChevronDown, File, Folder, FolderOpen, Plus, Trash2, Edit3, MoreVertical } from 'lucide-react';
import { FileNode } from '@shared/schema';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

interface FileTreeProps {
  nodes: FileNode[];
  selectedPath?: string;
  onFileSelect: (node: FileNode) => void;
  onFileCreate: (parentPath: string, type: 'file' | 'folder') => void;
  onFileDelete: (path: string) => void;
  onFileRename: (path: string) => void;
}

interface FileTreeNodeProps {
  node: FileNode;
  level: number;
  selectedPath?: string;
  onFileSelect: (node: FileNode) => void;
  onFileCreate: (parentPath: string, type: 'file' | 'folder') => void;
  onFileDelete: (path: string) => void;
  onFileRename: (path: string) => void;
  onToggle: (nodeId: string) => void;
}

function FileTreeNode({
  node,
  level,
  selectedPath,
  onFileSelect,
  onFileCreate,
  onFileDelete,
  onFileRename,
  onToggle,
}: FileTreeNodeProps) {
  const isFolder = node.type === 'folder';
  const isSelected = selectedPath === node.path;
  const isOpen = node.isOpen ?? false;

  const handleClick = () => {
    if (isFolder) {
      onToggle(node.id);
    } else {
      onFileSelect(node);
    }
  };

  const getFileIcon = () => {
    if (isFolder) {
      return isOpen ? <FolderOpen className="w-4 h-4" /> : <Folder className="w-4 h-4" />;
    }
    return <File className="w-4 h-4" />;
  };

  const getLanguageColor = () => {
    const ext = node.name.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'ts':
      case 'tsx':
        return 'text-[hsl(199,89%,48%)]';
      case 'js':
      case 'jsx':
        return 'text-[hsl(38,92%,65%)]';
      case 'py':
        return 'text-[hsl(199,89%,58%)]';
      case 'json':
        return 'text-[hsl(142,71%,55%)]';
      case 'css':
      case 'scss':
        return 'text-[hsl(262,83%,62%)]';
      case 'html':
        return 'text-[hsl(0,84%,60%)]';
      default:
        return 'text-muted-foreground';
    }
  };

  return (
    <div>
      <div
        className={cn(
          'group flex items-center gap-1 py-1 px-2 cursor-pointer hover-elevate rounded-md transition-colors',
          isSelected && 'bg-sidebar-accent text-sidebar-accent-foreground'
        )}
        style={{ paddingLeft: `${level * 16 + 8}px` }}
        onClick={handleClick}
        data-testid={`file-tree-item-${node.path}`}
      >
        {isFolder && (
          <button
            className="p-0 hover:bg-transparent"
            onClick={(e) => {
              e.stopPropagation();
              onToggle(node.id);
            }}
            data-testid={`folder-toggle-${node.path}`}
          >
            {isOpen ? (
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            )}
          </button>
        )}
        {!isFolder && <div className="w-4" />}
        <span className={cn('flex-shrink-0', getLanguageColor())}>{getFileIcon()}</span>
        <span className="flex-1 text-sm truncate font-mono">{node.name}</span>
        <DropdownMenu>
          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
            <Button
              variant="ghost"
              size="icon"
              className="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
              data-testid={`file-menu-${node.path}`}
            >
              <MoreVertical className="w-3 h-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            {isFolder && (
              <>
                <DropdownMenuItem onClick={() => onFileCreate(node.path, 'file')} data-testid={`create-file-${node.path}`}>
                  <Plus className="w-4 h-4 mr-2" />
                  New File
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onFileCreate(node.path, 'folder')} data-testid={`create-folder-${node.path}`}>
                  <Plus className="w-4 h-4 mr-2" />
                  New Folder
                </DropdownMenuItem>
              </>
            )}
            <DropdownMenuItem onClick={() => onFileRename(node.path)} data-testid={`rename-${node.path}`}>
              <Edit3 className="w-4 h-4 mr-2" />
              Rename
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => onFileDelete(node.path)}
              className="text-destructive"
              data-testid={`delete-${node.path}`}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      {isFolder && isOpen && node.children && (
        <div>
          {node.children.map((child) => (
            <FileTreeNode
              key={child.id}
              node={child}
              level={level + 1}
              selectedPath={selectedPath}
              onFileSelect={onFileSelect}
              onFileCreate={onFileCreate}
              onFileDelete={onFileDelete}
              onFileRename={onFileRename}
              onToggle={onToggle}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function FileTree({
  nodes,
  selectedPath,
  onFileSelect,
  onFileCreate,
  onFileDelete,
  onFileRename,
}: FileTreeProps) {
  const [openFolders, setOpenFolders] = useState<Set<string>>(new Set());

  const handleToggle = (nodeId: string) => {
    setOpenFolders((prev) => {
      const next = new Set(prev);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  };

  const updateNodesWithOpenState = (nodes: FileNode[]): FileNode[] => {
    return nodes.map((node) => ({
      ...node,
      isOpen: openFolders.has(node.id),
      children: node.children ? updateNodesWithOpenState(node.children) : undefined,
    }));
  };

  const updatedNodes = updateNodesWithOpenState(nodes);

  return (
    <div className="h-full overflow-y-auto overflow-x-hidden" data-testid="file-tree">
      <div className="py-2">
        {updatedNodes.map((node: FileNode) => (
          <FileTreeNode
            key={node.id}
            node={node}
            level={0}
            selectedPath={selectedPath}
            onFileSelect={onFileSelect}
            onFileCreate={onFileCreate}
            onFileDelete={onFileDelete}
            onFileRename={onFileRename}
            onToggle={handleToggle}
          />
        ))}
      </div>
    </div>
  );
}

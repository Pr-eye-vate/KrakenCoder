import { useRef, useEffect } from 'react';
import Editor, { OnMount } from '@monaco-editor/react';
import * as monaco from 'monaco-editor';

interface CodeEditorProps {
  value: string;
  language: string;
  onChange: (value: string | undefined) => void;
  onCursorChange?: (position: { lineNumber: number; column: number }) => void;
  readOnly?: boolean;
}

export function CodeEditor({ value, language, onChange, onCursorChange, readOnly }: CodeEditorProps) {
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);

  const handleEditorDidMount: OnMount = (editor, monaco) => {
    editorRef.current = editor;

    // Configure editor theme
    monaco.editor.defineTheme('codeforge-dark', {
      base: 'vs-dark',
      inherit: true,
      rules: [
        { token: 'comment', foreground: '6c7a8a', fontStyle: 'italic' },
        { token: 'keyword', foreground: 'c792ea' },
        { token: 'string', foreground: '8ec07c' },
        { token: 'number', foreground: 'f9bb57' },
        { token: 'type', foreground: '7fc8de' },
        { token: 'function', foreground: '7fc8de' },
        { token: 'variable', foreground: 'f5f7fa' },
      ],
      colors: {
        'editor.background': '#1c1e26',
        'editor.foreground': '#f5f7fa',
        'editor.lineHighlightBackground': '#252831',
        'editor.selectionBackground': '#3d4758',
        'editorCursor.foreground': '#a855f7',
        'editorLineNumber.foreground': '#6c7a8a',
        'editorLineNumber.activeForeground': '#a5b4c5',
        'editor.findMatchBackground': '#515c6a',
        'editor.findMatchHighlightBackground': '#515c6a60',
      },
    });

    monaco.editor.setTheme('codeforge-dark');

    // Track cursor position
    editor.onDidChangeCursorPosition((e) => {
      if (onCursorChange) {
        onCursorChange({
          lineNumber: e.position.lineNumber,
          column: e.position.column,
        });
      }
    });

    // Focus the editor
    editor.focus();
  };

  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.layout();
    }
  }, []);

  return (
    <div className="h-full w-full" data-testid="code-editor">
      <Editor
        height="100%"
        language={language}
        value={value}
        onChange={onChange}
        onMount={handleEditorDidMount}
        options={{
          fontSize: 14,
          fontFamily: 'JetBrains Mono, Fira Code, Consolas, monospace',
          fontLigatures: true,
          lineHeight: 1.6,
          minimap: { enabled: true },
          scrollBeyondLastLine: false,
          renderWhitespace: 'selection',
          cursorBlinking: 'smooth',
          cursorSmoothCaretAnimation: 'on',
          smoothScrolling: true,
          formatOnPaste: true,
          formatOnType: true,
          autoClosingBrackets: 'always',
          autoClosingQuotes: 'always',
          suggestOnTriggerCharacters: true,
          quickSuggestions: true,
          wordWrap: 'on',
          readOnly: readOnly,
          tabSize: 2,
          insertSpaces: true,
          detectIndentation: true,
        }}
        theme="codeforge-dark"
      />
    </div>
  );
}

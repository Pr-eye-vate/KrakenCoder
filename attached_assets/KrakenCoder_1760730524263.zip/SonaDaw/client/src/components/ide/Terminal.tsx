import { useEffect, useRef } from 'react';
import { Terminal as XTerm } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import { WebLinksAddon } from '@xterm/addon-web-links';
import '@xterm/xterm/css/xterm.css';
import { TerminalSession } from '@shared/schema';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Plus, X } from 'lucide-react';

interface TerminalProps {
  sessions: TerminalSession[];
  activeSessionId?: string;
  onSessionChange: (sessionId: string) => void;
  onSessionCreate: () => void;
  onSessionClose: (sessionId: string) => void;
  onCommand: (sessionId: string, command: string) => void;
}

function TerminalPane({
  sessionId,
  isActive,
  onCommand,
}: {
  sessionId: string;
  isActive: boolean;
  onCommand: (command: string) => void;
}) {
  const terminalRef = useRef<HTMLDivElement>(null);
  const xtermRef = useRef<XTerm | null>(null);
  const fitAddonRef = useRef<FitAddon | null>(null);
  const commandBufferRef = useRef<string>('');

  useEffect(() => {
    if (!terminalRef.current || xtermRef.current) return;

    const xterm = new XTerm({
      fontFamily: 'JetBrains Mono, Fira Code, Consolas, monospace',
      fontSize: 13,
      lineHeight: 1.5,
      cursorBlink: true,
      cursorStyle: 'bar',
      theme: {
        background: '#16181d',
        foreground: '#f5f7fa',
        cursor: '#a855f7',
        cursorAccent: '#16181d',
        black: '#16181d',
        red: '#f87171',
        green: '#8ec07c',
        yellow: '#f9bb57',
        blue: '#7fc8de',
        magenta: '#c792ea',
        cyan: '#7fc8de',
        white: '#f5f7fa',
        brightBlack: '#6c7a8a',
        brightRed: '#f87171',
        brightGreen: '#8ec07c',
        brightYellow: '#f9bb57',
        brightBlue: '#7fc8de',
        brightMagenta: '#c792ea',
        brightCyan: '#7fc8de',
        brightWhite: '#ffffff',
      },
    });

    const fitAddon = new FitAddon();
    const webLinksAddon = new WebLinksAddon();

    xterm.loadAddon(fitAddon);
    xterm.loadAddon(webLinksAddon);

    xterm.open(terminalRef.current);
    fitAddon.fit();

    // Welcome message
    xterm.writeln('\x1b[1;35m╔════════════════════════════════════════╗\x1b[0m');
    xterm.writeln('\x1b[1;35m║       CodeForge Terminal v1.0         ║\x1b[0m');
    xterm.writeln('\x1b[1;35m╚════════════════════════════════════════╝\x1b[0m');
    xterm.writeln('');
    xterm.write('\x1b[1;36m$\x1b[0m ');

    // Handle input
    xterm.onData((data) => {
      if (data === '\r') {
        // Enter key
        xterm.writeln('');
        const command = commandBufferRef.current.trim();
        if (command) {
          onCommand(command);
          commandBufferRef.current = '';
        }
        xterm.write('\x1b[1;36m$\x1b[0m ');
      } else if (data === '\u007F') {
        // Backspace
        if (commandBufferRef.current.length > 0) {
          commandBufferRef.current = commandBufferRef.current.slice(0, -1);
          xterm.write('\b \b');
        }
      } else if (data === '\u0003') {
        // Ctrl+C
        xterm.writeln('^C');
        commandBufferRef.current = '';
        xterm.write('\x1b[1;36m$\x1b[0m ');
      } else {
        commandBufferRef.current += data;
        xterm.write(data);
      }
    });

    xtermRef.current = xterm;
    fitAddonRef.current = fitAddon;

    // Handle resize
    const resizeObserver = new ResizeObserver(() => {
      fitAddon.fit();
    });

    if (terminalRef.current) {
      resizeObserver.observe(terminalRef.current);
    }

    return () => {
      resizeObserver.disconnect();
      xterm.dispose();
    };
  }, [sessionId, onCommand]);

  useEffect(() => {
    if (isActive && fitAddonRef.current) {
      setTimeout(() => {
        fitAddonRef.current?.fit();
      }, 0);
    }
  }, [isActive]);

  return <div ref={terminalRef} className="h-full w-full" data-testid={`terminal-pane-${sessionId}`} />;
}

export function Terminal({
  sessions,
  activeSessionId,
  onSessionChange,
  onSessionCreate,
  onSessionClose,
  onCommand,
}: TerminalProps) {
  const currentSession = activeSessionId || sessions[0]?.id;

  return (
    <div className="h-full flex flex-col bg-[#16181d]" data-testid="terminal">
      <Tabs value={currentSession} onValueChange={onSessionChange} className="flex-1 flex flex-col">
        <div className="flex items-center justify-between border-b border-border px-2">
          <TabsList className="h-9 bg-transparent">
            {sessions.map((session) => (
              <TabsTrigger
                key={session.id}
                value={session.id}
                className="group relative data-[state=active]:bg-background/10"
                data-testid={`terminal-tab-${session.id}`}
              >
                {session.name}
                {sessions.length > 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-4 h-4 ml-2 opacity-0 group-hover:opacity-100"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSessionClose(session.id);
                    }}
                    data-testid={`terminal-close-${session.id}`}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                )}
              </TabsTrigger>
            ))}
          </TabsList>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={onSessionCreate}
            data-testid="terminal-new-session"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>
        {sessions.map((session) => (
          <TabsContent key={session.id} value={session.id} className="flex-1 m-0 p-2">
            <TerminalPane
              sessionId={session.id}
              isActive={currentSession === session.id}
              onCommand={(cmd) => onCommand(session.id, cmd)}
            />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

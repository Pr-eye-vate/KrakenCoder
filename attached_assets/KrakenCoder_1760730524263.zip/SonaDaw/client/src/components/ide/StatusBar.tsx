import { GitBranch, AlertCircle, CheckCircle, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatusBarProps {
  cursorPosition?: { lineNumber: number; column: number };
  language?: string;
  fileEncoding?: string;
  aiStatus?: 'idle' | 'thinking' | 'ready';
  errors?: number;
  warnings?: number;
}

export function StatusBar({
  cursorPosition,
  language = 'plaintext',
  fileEncoding = 'UTF-8',
  aiStatus = 'ready',
  errors = 0,
  warnings = 0,
}: StatusBarProps) {
  return (
    <div className="h-6 bg-sidebar border-t border-border flex items-center justify-between px-3 text-xs font-mono" data-testid="status-bar">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <GitBranch className="w-3 h-3" />
          <span>main</span>
        </div>
        {(errors > 0 || warnings > 0) && (
          <div className="flex items-center gap-3">
            {errors > 0 && (
              <div className="flex items-center gap-1 text-destructive" data-testid="status-errors">
                <AlertCircle className="w-3 h-3" />
                <span>{errors}</span>
              </div>
            )}
            {warnings > 0 && (
              <div className="flex items-center gap-1 text-warning" data-testid="status-warnings">
                <AlertCircle className="w-3 h-3" />
                <span>{warnings}</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        {cursorPosition && (
          <span data-testid="cursor-position">
            Ln {cursorPosition.lineNumber}, Col {cursorPosition.column}
          </span>
        )}
        <span className="uppercase">{language}</span>
        <span>{fileEncoding}</span>
        <div
          className={cn(
            'flex items-center gap-1.5',
            aiStatus === 'thinking' && 'text-primary animate-pulse',
            aiStatus === 'ready' && 'text-success'
          )}
          data-testid="ai-status"
        >
          {aiStatus === 'ready' ? (
            <>
              <CheckCircle className="w-3 h-3" />
              <span>AI Ready</span>
            </>
          ) : aiStatus === 'thinking' ? (
            <>
              <Zap className="w-3 h-3" />
              <span>AI Thinking...</span>
            </>
          ) : (
            <>
              <Zap className="w-3 h-3 opacity-50" />
              <span>AI Idle</span>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

import { X } from 'lucide-react';
import { EditorTab } from '@shared/schema';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface EditorTabsProps {
  tabs: EditorTab[];
  activeTabId?: string;
  onTabClick: (tabId: string) => void;
  onTabClose: (tabId: string) => void;
}

export function EditorTabs({ tabs, activeTabId, onTabClick, onTabClose }: EditorTabsProps) {
  const getFileIcon = (language: string) => {
    switch (language) {
      case 'typescript':
      case 'javascript':
        return '○';
      case 'python':
        return '⊙';
      case 'html':
        return '▽';
      case 'css':
        return '▢';
      case 'json':
        return '◈';
      default:
        return '●';
    }
  };

  if (tabs.length === 0) {
    return null;
  }

  return (
    <div className="flex items-center h-10 bg-card border-b border-border overflow-x-auto scrollbar-thin" data-testid="editor-tabs">
      {tabs.map((tab) => (
        <div
          key={tab.id}
          className={cn(
            'group flex items-center gap-2 h-full px-4 border-r border-border cursor-pointer transition-colors min-w-[120px] max-w-[200px]',
            activeTabId === tab.id
              ? 'bg-background text-foreground'
              : 'bg-card text-muted-foreground hover-elevate'
          )}
          onClick={() => onTabClick(tab.id)}
          data-testid={`editor-tab-${tab.id}`}
        >
          <span className="text-xs">{getFileIcon(tab.language)}</span>
          <span className="flex-1 text-sm truncate font-mono">{tab.name}</span>
          {tab.isDirty && (
            <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0" data-testid={`tab-dirty-${tab.id}`} />
          )}
          <Button
            variant="ghost"
            size="icon"
            className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-destructive/20"
            onClick={(e) => {
              e.stopPropagation();
              onTabClose(tab.id);
            }}
            data-testid={`tab-close-${tab.id}`}
          >
            <X className="w-3 h-3" />
          </Button>
        </div>
      ))}
    </div>
  );
}
